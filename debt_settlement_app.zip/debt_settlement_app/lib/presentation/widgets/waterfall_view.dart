import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../domain/entities/financial_summary.dart';
import 'summary_card.dart';

/// Step-by-step visualization of the waterfall settlement simulation:
/// shows, in priority order, which creditors get paid from the available
/// cash pool and who is left unpaid at the end.
class WaterfallView extends StatelessWidget {
  final WaterfallResult result;

  const WaterfallView({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.surfaceElevated,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _miniStat('نقد اولیه', result.startingCash, AppColors.inflowGreen),
              _miniStat('باقی‌مانده نقد', result.cashRemainingAtEnd,
                  AppColors.gold),
              _miniStat('مانده پرداخت‌نشده', result.totalUnpaid,
                  AppColors.urgentRed),
            ],
          ),
        ),
        const SizedBox(height: 12),
        ...result.steps.map((step) => _StepTile(step: step)),
      ],
    );
  }

  Widget _miniStat(String label, double value, Color color) {
    return Column(
      children: [
        Text(label,
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 11)),
        const SizedBox(height: 4),
        Text(formatTomans(value),
            style: TextStyle(
                color: color, fontSize: 13, fontWeight: FontWeight.bold)),
      ],
    );
  }
}

class _StepTile extends StatelessWidget {
  final WaterfallStep step;
  const _StepTile({required this.step});

  @override
  Widget build(BuildContext context) {
    final color = step.fullyPaid ? AppColors.inflowGreen : AppColors.urgentRed;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border(right: BorderSide(color: color, width: 3)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('${step.creditorName}  (اولویت ${step.priorityLevel})',
                    style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w600,
                        fontSize: 13)),
                const SizedBox(height: 4),
                Text(
                  step.fullyPaid
                      ? 'کامل پرداخت شد: ${formatTomans(step.amountPaid)}'
                      : 'پرداخت جزئی: ${formatTomans(step.amountPaid)} — باقی: ${formatTomans(step.remainingAfter)}',
                  style: TextStyle(color: color, fontSize: 12),
                ),
              ],
            ),
          ),
          Icon(
            step.fullyPaid ? Icons.check_circle : Icons.error_outline,
            color: color,
            size: 20,
          ),
        ],
      ),
    );
  }
}
