import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'data/local/hive_service.dart';
import 'data/repositories/finance_repository.dart';
import 'presentation/providers/finance_provider.dart';
import 'presentation/screens/dashboard_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await HiveService.init(); // opens all local (offline) storage boxes
  runApp(const DebtSettlementApp());
}

class DebtSettlementApp extends StatelessWidget {
  const DebtSettlementApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => FinanceProvider(FinanceRepository()),
      child: MaterialApp(
        title: 'بازسازی مالی و تسویه بدهی',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        // Persian RTL locale support.
        locale: const Locale('fa', 'IR'),
        supportedLocales: const [Locale('fa', 'IR'), Locale('en', 'US')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const DashboardScreen(),
      ),
    );
  }
}
