import 'package:hive/hive.dart';
import '../../core/constants/app_constants.dart';

/// A creditor / debt line, ranked by priority (1 = most urgent).
class DebtModel extends HiveObject {
  String id;
  String creditorName;
  double amountTomans;
  DebtPriority priority;
  String collateralNote; // e.g. "در گرو ۱۶ گرم طلا" / "در گرو دلار"
  DebtStatus status;
  double paidSoFarTomans;

  DebtModel({
    required this.id,
    required this.creditorName,
    required this.amountTomans,
    required this.priority,
    this.collateralNote = '',
    this.status = DebtStatus.unpaid,
    this.paidSoFarTomans = 0,
  });

  double get remainingTomans =>
      (amountTomans - paidSoFarTomans).clamp(0, amountTomans);

  DebtModel copyWith({
    String? creditorName,
    double? amountTomans,
    DebtPriority? priority,
    String? collateralNote,
    DebtStatus? status,
    double? paidSoFarTomans,
  }) {
    return DebtModel(
      id: id,
      creditorName: creditorName ?? this.creditorName,
      amountTomans: amountTomans ?? this.amountTomans,
      priority: priority ?? this.priority,
      collateralNote: collateralNote ?? this.collateralNote,
      status: status ?? this.status,
      paidSoFarTomans: paidSoFarTomans ?? this.paidSoFarTomans,
    );
  }
}

class DebtModelAdapter extends TypeAdapter<DebtModel> {
  @override
  final int typeId = 1;

  @override
  DebtModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DebtModel(
      id: fields[0] as String,
      creditorName: fields[1] as String,
      amountTomans: fields[2] as double,
      priority: DebtPriority.values[fields[3] as int],
      collateralNote: fields[4] as String? ?? '',
      status: DebtStatus.values[fields[5] as int],
      paidSoFarTomans: fields[6] as double? ?? 0,
    );
  }

  @override
  void write(BinaryWriter writer, DebtModel obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.creditorName)
      ..writeByte(2)
      ..write(obj.amountTomans)
      ..writeByte(3)
      ..write(obj.priority.index)
      ..writeByte(4)
      ..write(obj.collateralNote)
      ..writeByte(5)
      ..write(obj.status.index)
      ..writeByte(6)
      ..write(obj.paidSoFarTomans);
  }
}
