import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../domain/entities/financial_summary.dart';
import '../providers/finance_provider.dart';
import '../widgets/summary_card.dart';
import '../widgets/waterfall_view.dart';
import 'debts_screen.dart';
import 'inflows_screen.dart';
import 'expenses_screen.dart';
import 'assets_screen.dart';

/// The cinematic financial-restructuring dashboard — the app's home screen.
/// Shows real-time totals, the Keep/Sell gold toggle, and the waterfall
/// settlement simulator, plus quick navigation to the four data screens.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _tabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(
          index: _tabIndex,
          children: const [
            _DashboardHome(),
            InflowsScreen(),
            DebtsScreen(),
            ExpensesScreen(),
            AssetsScreen(),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _tabIndex,
          onTap: (i) => setState(() => _tabIndex = i),
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
                icon: Icon(Icons.dashboard_outlined), label: 'داشبورد'),
            BottomNavigationBarItem(
                icon: Icon(Icons.call_received), label: 'ورودی‌ها'),
            BottomNavigationBarItem(
                icon: Icon(Icons.priority_high), label: 'بدهی‌ها'),
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_bag_outlined), label: 'هزینه‌ها'),
            BottomNavigationBarItem(
                icon: Icon(Icons.diamond_outlined), label: 'دارایی‌ها'),
          ],
        ),
      ),
    );
  }
}

class _DashboardHome extends StatelessWidget {
  const _DashboardHome();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();

    if (provider.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator(color: AppColors.gold)),
      );
    }

    final summary = provider.summary;
    final vault = provider.vault;
    final keepGold = vault?.keepGold ?? true;
    final netResult =
        keepGold ? summary.netResultGoldKept : summary.netResultGoldSold;

    return Scaffold(
      appBar: AppBar(
        title: const Text('بازسازی مالی و تسویه بدهی'),
      ),
      body: RefreshIndicator(
        onRefresh: () async {},
        color: AppColors.gold,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _NetResultHero(netResult: netResult, keepGold: keepGold),
            const SizedBox(height: 20),

            const _SectionTitle('خلاصه وضعیت مالی'),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.3,
              children: [
                SummaryCard(
                  label: 'مجموع ورودی نقد (وصول‌شده)',
                  value: summary.totalInflowsReceived,
                  accentColor: AppColors.inflowGreen,
                  icon: Icons.call_received,
                ),
                SummaryCard(
                  label: 'مجموع بدهی باقی‌مانده',
                  value: summary.totalDebtRemaining,
                  accentColor: AppColors.urgentRed,
                  icon: Icons.priority_high,
                ),
                SummaryCard(
                  label: 'هزینه‌های ضروری',
                  value: summary.totalEssentialExpenses,
                  accentColor: AppColors.pendingAmber,
                  icon: Icons.shopping_bag_outlined,
                ),
                SummaryCard(
                  label: 'ارزش طلا (${vault?.goldGrams.toStringAsFixed(1) ?? 0} گرم)',
                  value: summary.goldValueTomans,
                  accentColor: AppColors.gold,
                  icon: Icons.diamond_outlined,
                ),
              ],
            ),

            const SizedBox(height: 24),
            const _SectionTitle('گزینه طلا: نگه‌داری یا فروش'),
            const SizedBox(height: 10),
            _GoldToggleCard(keepGold: keepGold, summary: summary),

            const SizedBox(height: 24),
            Row(
              children: [
                const _SectionTitle('شبیه‌ساز تسویه آبشاری'),
                const Spacer(),
                Text(
                  keepGold ? 'حالت: طلا نگه‌داری شود' : 'حالت: طلا فروخته شود',
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 11),
                ),
              ],
            ),
            const SizedBox(height: 10),
            WaterfallView(
              result: provider.waterfall(includeGold: !keepGold),
            ),
          ],
        ),
      ),
    );
  }
}

class _NetResultHero extends StatelessWidget {
  final double netResult;
  final bool keepGold;

  const _NetResultHero({required this.netResult, required this.keepGold});

  @override
  Widget build(BuildContext context) {
    final isDeficit = netResult < 0;
    final color = isDeficit ? AppColors.urgentRed : AppColors.inflowGreen;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.18), AppColors.surface],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Column(
        children: [
          Text(
            isDeficit ? 'کسری نقدی خالص' : 'مانده مثبت (سرپلاس)',
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
          ),
          const SizedBox(height: 10),
          Text(
            formatTomans(netResult),
            style: TextStyle(
              color: color,
              fontSize: 30,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            keepGold
                ? '(طلا در محاسبه نقدینگی لحاظ نشده — به‌عنوان ذخیره حفظ شده)'
                : '(طلا فروخته و به نقدینگی افزوده شده)',
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 11),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _GoldToggleCard extends StatelessWidget {
  final bool keepGold;
  final FinancialSummary summary;

  const _GoldToggleCard({required this.keepGold, required this.summary});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<FinanceProvider>();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.gold.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  keepGold ? 'طلا نگه‌داری می‌شود' : 'طلا فروخته می‌شود',
                  style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w600),
                  textAlign: TextAlign.right,
                ),
              ),
              Switch(
                value: !keepGold,
                activeColor: AppColors.gold,
                onChanged: (sell) => provider.toggleKeepGold(!sell),
              ),
            ],
          ),
          const Divider(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _resultColumn('اگر طلا فروخته شود',
                  summary.netResultGoldSold, AppColors.inflowGreen),
              Container(width: 1, height: 40, color: AppColors.border),
              _resultColumn('اگر طلا نگه‌داری شود',
                  summary.netResultGoldKept, AppColors.gold),
            ],
          ),
        ],
      ),
    );
  }

  Widget _resultColumn(String label, double value, Color color) {
    return Column(
      children: [
        Text(label,
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 11)),
        const SizedBox(height: 6),
        Text(formatTomans(value),
            style: TextStyle(
                color: value < 0 ? AppColors.urgentRed : color,
                fontWeight: FontWeight.bold,
                fontSize: 13)),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Text(
        text,
        style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 15,
            fontWeight: FontWeight.bold),
      ),
    );
  }
}
