import 'package:flutter/material.dart';

/// Cinematic, minimalist dark theme for the Iranian financial dashboard.
/// Color language:
///   - Red    -> urgent / priority-1 debts, deficit
///   - Gold   -> assets (gold grams, currency vault)
///   - Green  -> inflows, surplus, "paid" status
///   - Amber  -> "partial" / pending states
class AppColors {
  static const background = Color(0xFF0B0E14);
  static const surface = Color(0xFF141821);
  static const surfaceElevated = Color(0xFF1C212C);
  static const border = Color(0xFF2A303C);

  static const textPrimary = Color(0xFFEDEFF3);
  static const textSecondary = Color(0xFF9BA3B4);

  static const urgentRed = Color(0xFFE5484D);
  static const gold = Color(0xFFD4AF37);
  static const inflowGreen = Color(0xFF3DDC97);
  static const pendingAmber = Color(0xFFF5A623);
  static const usdBlue = Color(0xFF5B8DEF);
  static const eurPurple = Color(0xFFB185F0);
}

class AppTheme {
  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: base.colorScheme.copyWith(
        surface: AppColors.surface,
        primary: AppColors.gold,
        secondary: AppColors.inflowGreen,
        error: AppColors.urgentRed,
      ),
      // NOTE: bundle a Persian-supporting font (e.g. Vazirmatn) via pubspec
      // and set fontFamily below for correct Farsi glyph shaping.
      fontFamily: 'Vazirmatn',
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.textPrimary,
        displayColor: AppColors.textPrimary,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        elevation: 0,
        centerTitle: true,
        foregroundColor: AppColors.textPrimary,
      ),
      cardTheme: CardThemeData(
        color: AppColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: AppColors.border),
        ),
      ),
      dividerColor: AppColors.border,
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: AppColors.gold,
        unselectedItemColor: AppColors.textSecondary,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceElevated,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.gold,
          foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        ),
      ),
    );
  }
}
