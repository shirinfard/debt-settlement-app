import 'package:hive/hive.dart';
import '../../core/constants/app_constants.dart';

/// A single cash inflow / resource (loan, asset sale, property advance...).
class InflowModel extends HiveObject {
  String id;
  String title;
  double amountTomans;
  InflowStatus status;
  DateTime? targetDate;
  String notes;

  InflowModel({
    required this.id,
    required this.title,
    required this.amountTomans,
    required this.status,
    this.targetDate,
    this.notes = '',
  });

  InflowModel copyWith({
    String? title,
    double? amountTomans,
    InflowStatus? status,
    DateTime? targetDate,
    String? notes,
  }) {
    return InflowModel(
      id: id,
      title: title ?? this.title,
      amountTomans: amountTomans ?? this.amountTomans,
      status: status ?? this.status,
      targetDate: targetDate ?? this.targetDate,
      notes: notes ?? this.notes,
    );
  }
}

/// Manual TypeAdapter — avoids requiring build_runner/hive_generator so the
/// project compiles immediately after `flutter pub get`.
class InflowModelAdapter extends TypeAdapter<InflowModel> {
  @override
  final int typeId = 0;

  @override
  InflowModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return InflowModel(
      id: fields[0] as String,
      title: fields[1] as String,
      amountTomans: fields[2] as double,
      status: InflowStatus.values[fields[3] as int],
      targetDate: fields[4] as DateTime?,
      notes: fields[5] as String? ?? '',
    );
  }

  @override
  void write(BinaryWriter writer, InflowModel obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.amountTomans)
      ..writeByte(3)
      ..write(obj.status.index)
      ..writeByte(4)
      ..write(obj.targetDate)
      ..writeByte(5)
      ..write(obj.notes);
  }
}
