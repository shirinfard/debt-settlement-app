import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/debt_model.dart';
import '../providers/finance_provider.dart';
import '../widgets/priority_tag.dart';
import '../widgets/summary_card.dart';

/// Lists all creditors sorted by priority (most urgent first) and lets the
/// user add new debts or record payments against existing ones.
class DebtsScreen extends StatelessWidget {
  const DebtsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();
    final debts = provider.debtsByPriority;

    return Scaffold(
      appBar: AppBar(title: const Text('بدهی‌ها و طلبکاران')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.urgentRed,
        onPressed: () => _showAddDebtSheet(context),
        child: const Icon(Icons.add),
      ),
      body: debts.isEmpty
          ? const Center(
              child: Text('هنوز بدهی‌ای ثبت نشده است.',
                  style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: debts.length,
              itemBuilder: (context, i) => _DebtTile(debt: debts[i]),
            ),
    );
  }

  void _showAddDebtSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const _AddDebtSheet(),
    );
  }
}

class _DebtTile extends StatelessWidget {
  final DebtModel debt;
  const _DebtTile({required this.debt});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<FinanceProvider>();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              StatusTag.debt(debt.status),
              const Spacer(),
              Text(debt.creditorName,
                  style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 15)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              PriorityTag(priority: debt.priority),
              Text(formatTomans(debt.remainingTomans),
                  style: const TextStyle(
                      color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
            ],
          ),
          if (debt.collateralNote.isNotEmpty) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: Text('وثیقه: ${debt.collateralNote}',
                  style: const TextStyle(
                      color: AppColors.gold, fontSize: 12)),
            ),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _recordPaymentDialog(context, provider),
                  child: const Text('ثبت پرداخت'),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppColors.urgentRed),
                onPressed: () => provider.deleteDebt(debt.id),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _recordPaymentDialog(BuildContext context, FinanceProvider provider) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surfaceElevated,
        title: const Text('ثبت پرداخت'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'مبلغ (تومان)'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('انصراف')),
          ElevatedButton(
            onPressed: () {
              final amount = double.tryParse(controller.text) ?? 0;
              if (amount > 0) provider.recordPayment(debt.id, amount);
              Navigator.pop(context);
            },
            child: const Text('ثبت'),
          ),
        ],
      ),
    );
  }
}

class _AddDebtSheet extends StatefulWidget {
  const _AddDebtSheet();

  @override
  State<_AddDebtSheet> createState() => _AddDebtSheetState();
}

class _AddDebtSheetState extends State<_AddDebtSheet> {
  final _nameCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  final _collateralCtrl = TextEditingController();
  DebtPriority _priority = DebtPriority.p3;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: 20 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('افزودن بدهی جدید',
              style: TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
          const SizedBox(height: 16),
          TextField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'نام طلبکار')),
          const SizedBox(height: 12),
          TextField(
            controller: _amountCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'مبلغ (تومان)'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<DebtPriority>(
            value: _priority,
            dropdownColor: AppColors.surfaceElevated,
            decoration: const InputDecoration(labelText: 'سطح اولویت'),
            items: DebtPriority.values
                .map((p) => DropdownMenuItem(
                    value: p, child: Text('اولویت ${p.level} — ${p.label}')))
                .toList(),
            onChanged: (v) => setState(() => _priority = v ?? _priority),
          ),
          const SizedBox(height: 12),
          TextField(
              controller: _collateralCtrl,
              decoration: const InputDecoration(
                  labelText: 'یادداشت وثیقه (اختیاری)')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _submit,
            child: const Text('ذخیره'),
          ),
        ],
      ),
    );
  }

  void _submit() {
    final name = _nameCtrl.text.trim();
    final amount = double.tryParse(_amountCtrl.text) ?? 0;
    if (name.isEmpty || amount <= 0) return;
    context.read<FinanceProvider>().addDebt(
          creditorName: name,
          amountTomans: amount,
          priority: _priority,
          collateralNote: _collateralCtrl.text.trim(),
        );
    Navigator.pop(context);
  }
}
