import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/finance_provider.dart';
import '../widgets/priority_tag.dart';
import '../widgets/summary_card.dart';

/// Lists cash inflows / resources (loans, asset sales, advances...).
class InflowsScreen extends StatelessWidget {
  const InflowsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();
    final inflows = provider.inflows;

    return Scaffold(
      appBar: AppBar(title: const Text('ورودی‌ها و منابع نقدی')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.inflowGreen,
        onPressed: () => _showAddSheet(context),
        child: const Icon(Icons.add, color: Colors.black),
      ),
      body: inflows.isEmpty
          ? const Center(
              child: Text('هنوز ورودی‌ای ثبت نشده است.',
                  style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: inflows.length,
              itemBuilder: (context, i) {
                final item = inflows[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.delete_outline,
                            color: AppColors.urgentRed, size: 20),
                        onPressed: () => provider.deleteInflow(item.id),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(item.title,
                                style: const TextStyle(
                                    color: AppColors.textPrimary,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                StatusTag.inflow(item.status),
                                const SizedBox(width: 8),
                                Text(formatTomans(item.amountTomans),
                                    style: const TextStyle(
                                        color: AppColors.inflowGreen,
                                        fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  void _showAddSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const _AddInflowSheet(),
    );
  }
}

class _AddInflowSheet extends StatefulWidget {
  const _AddInflowSheet();
  @override
  State<_AddInflowSheet> createState() => _AddInflowSheetState();
}

class _AddInflowSheetState extends State<_AddInflowSheet> {
  final _titleCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  InflowStatus _status = InflowStatus.pending;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: 20 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('افزودن ورودی جدید',
              style: TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
          const SizedBox(height: 16),
          TextField(
              controller: _titleCtrl,
              decoration: const InputDecoration(
                  labelText: 'عنوان (مثلا: وام، فروش موتور)')),
          const SizedBox(height: 12),
          TextField(
            controller: _amountCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'مبلغ (تومان)'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<InflowStatus>(
            value: _status,
            dropdownColor: AppColors.surfaceElevated,
            decoration: const InputDecoration(labelText: 'وضعیت'),
            items: InflowStatus.values
                .map((s) => DropdownMenuItem(value: s, child: Text(s.label)))
                .toList(),
            onChanged: (v) => setState(() => _status = v ?? _status),
          ),
          const SizedBox(height: 12),
          TextField(
              controller: _notesCtrl,
              decoration: const InputDecoration(labelText: 'یادداشت (اختیاری)')),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: _submit, child: const Text('ذخیره')),
        ],
      ),
    );
  }

  void _submit() {
    final title = _titleCtrl.text.trim();
    final amount = double.tryParse(_amountCtrl.text) ?? 0;
    if (title.isEmpty || amount <= 0) return;
    context.read<FinanceProvider>().addInflow(
          title: title,
          amountTomans: amount,
          status: _status,
          notes: _notesCtrl.text.trim(),
        );
    Navigator.pop(context);
  }
}
