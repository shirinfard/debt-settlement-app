import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../providers/finance_provider.dart';
import '../widgets/summary_card.dart';

/// Asset Vault: gold (grams) + USD/EUR on hand, daily exchange rate entry,
/// and the Keep/Sell gold decision that feeds the dashboard's net result.
class AssetsScreen extends StatefulWidget {
  const AssetsScreen({super.key});

  @override
  State<AssetsScreen> createState() => _AssetsScreenState();
}

class _AssetsScreenState extends State<AssetsScreen> {
  late TextEditingController _goldCtrl;
  late TextEditingController _usdCtrl;
  late TextEditingController _eurCtrl;
  late TextEditingController _usdRateCtrl;
  late TextEditingController _eurRateCtrl;
  late TextEditingController _goldRateCtrl;
  bool _initialized = false;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();
    final vault = provider.vault;
    final rates = provider.rates;

    if (!_initialized) {
      _goldCtrl = TextEditingController(text: vault?.goldGrams.toString() ?? '');
      _usdCtrl = TextEditingController(text: vault?.usdOnHand.toString() ?? '');
      _eurCtrl = TextEditingController(text: vault?.eurOnHand.toString() ?? '');
      _usdRateCtrl =
          TextEditingController(text: rates?.usdToTomans.toString() ?? '');
      _eurRateCtrl =
          TextEditingController(text: rates?.eurToTomans.toString() ?? '');
      _goldRateCtrl =
          TextEditingController(text: rates?.goldPerGramTomans.toString() ?? '');
      _initialized = true;
    }

    final summary = provider.summary;

    return Scaffold(
      appBar: AppBar(title: const Text('دارایی‌های ارزی و طلا')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _Label('موجودی دارایی'),
          const SizedBox(height: 10),
          _numberField(_goldCtrl, 'طلا (گرم)', AppColors.gold),
          const SizedBox(height: 10),
          _numberField(_usdCtrl, 'دلار موجود (USD)', AppColors.usdBlue),
          const SizedBox(height: 10),
          _numberField(_eurCtrl, 'یورو موجود (EUR)', AppColors.eurPurple),
          const SizedBox(height: 20),

          const _Label('نرخ روز ارز و طلا'),
          const SizedBox(height: 10),
          _numberField(_usdRateCtrl, 'نرخ دلار (تومان)', AppColors.usdBlue),
          const SizedBox(height: 10),
          _numberField(_eurRateCtrl, 'نرخ یورو (تومان)', AppColors.eurPurple),
          const SizedBox(height: 10),
          _numberField(_goldRateCtrl, 'نرخ هر گرم طلا (تومان)', AppColors.gold),
          const SizedBox(height: 16),

          ElevatedButton(
            onPressed: () => _save(context),
            child: const Text('ذخیره موجودی و نرخ‌ها'),
          ),

          const SizedBox(height: 24),
          const _Label('ارزش دارایی‌ها به تومان'),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.3,
            children: [
              SummaryCard(
                  label: 'ارزش طلا',
                  value: summary.goldValueTomans,
                  accentColor: AppColors.gold,
                  icon: Icons.diamond_outlined),
              SummaryCard(
                  label: 'ارزش دلار',
                  value: summary.usdValueTomans,
                  accentColor: AppColors.usdBlue,
                  icon: Icons.attach_money),
              SummaryCard(
                  label: 'ارزش یورو',
                  value: summary.eurValueTomans,
                  accentColor: AppColors.eurPurple,
                  icon: Icons.euro),
            ],
          ),
        ],
      ),
    );
  }

  Widget _numberField(TextEditingController ctrl, String label, Color color) {
    return TextField(
      controller: ctrl,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      style: TextStyle(color: color),
      decoration: InputDecoration(labelText: label),
    );
  }

  void _save(BuildContext context) {
    final provider = context.read<FinanceProvider>();
    provider.updateVault(
      goldGrams: double.tryParse(_goldCtrl.text) ?? 0,
      usdOnHand: double.tryParse(_usdCtrl.text) ?? 0,
      eurOnHand: double.tryParse(_eurCtrl.text) ?? 0,
      keepGold: provider.vault?.keepGold ?? true,
    );
    provider.updateRates(
      usdToTomans: double.tryParse(_usdRateCtrl.text) ?? 0,
      eurToTomans: double.tryParse(_eurRateCtrl.text) ?? 0,
      goldPerGramTomans: double.tryParse(_goldRateCtrl.text) ?? 0,
    );
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('ذخیره شد')),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Text(text,
          style: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.bold,
              fontSize: 15)),
    );
  }
}
