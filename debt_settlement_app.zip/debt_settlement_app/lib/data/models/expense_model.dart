import 'package:hive/hive.dart';
import '../../core/constants/app_constants.dart';

/// A planned or incurred expense / purchase.
class ExpenseModel extends HiveObject {
  String id;
  String itemName;
  double costTomans;
  ExpenseCategory category;
  bool isEssential;

  ExpenseModel({
    required this.id,
    required this.itemName,
    required this.costTomans,
    required this.category,
    required this.isEssential,
  });

  ExpenseModel copyWith({
    String? itemName,
    double? costTomans,
    ExpenseCategory? category,
    bool? isEssential,
  }) {
    return ExpenseModel(
      id: id,
      itemName: itemName ?? this.itemName,
      costTomans: costTomans ?? this.costTomans,
      category: category ?? this.category,
      isEssential: isEssential ?? this.isEssential,
    );
  }
}

class ExpenseModelAdapter extends TypeAdapter<ExpenseModel> {
  @override
  final int typeId = 2;

  @override
  ExpenseModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ExpenseModel(
      id: fields[0] as String,
      itemName: fields[1] as String,
      costTomans: fields[2] as double,
      category: ExpenseCategory.values[fields[3] as int],
      isEssential: fields[4] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ExpenseModel obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.itemName)
      ..writeByte(2)
      ..write(obj.costTomans)
      ..writeByte(3)
      ..write(obj.category.index)
      ..writeByte(4)
      ..write(obj.isEssential);
  }
}
