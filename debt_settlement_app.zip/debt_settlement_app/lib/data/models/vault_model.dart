import 'package:hive/hive.dart';

/// Daily exchange rates entered by the user. Only ONE instance is kept
/// (stored at key 'current' in HiveBoxes.rates) — it represents "today's rates".
class DailyRatesModel extends HiveObject {
  double usdToTomans;
  double eurToTomans;
  double goldPerGramTomans;
  DateTime updatedAt;

  DailyRatesModel({
    required this.usdToTomans,
    required this.eurToTomans,
    required this.goldPerGramTomans,
    required this.updatedAt,
  });
}

class DailyRatesModelAdapter extends TypeAdapter<DailyRatesModel> {
  @override
  final int typeId = 3;

  @override
  DailyRatesModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DailyRatesModel(
      usdToTomans: fields[0] as double,
      eurToTomans: fields[1] as double,
      goldPerGramTomans: fields[2] as double,
      updatedAt: fields[3] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, DailyRatesModel obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.usdToTomans)
      ..writeByte(1)
      ..write(obj.eurToTomans)
      ..writeByte(2)
      ..write(obj.goldPerGramTomans)
      ..writeByte(3)
      ..write(obj.updatedAt);
  }
}

/// The physical/currency asset vault the user holds.
/// `keepGold = true` means the "Keep" toggle is active — gold is NOT counted
/// as liquid cash in the deficit calculation (it is preserved as a hedge).
class AssetVaultModel extends HiveObject {
  double goldGrams;
  double usdOnHand;
  double eurOnHand;
  bool keepGold;

  AssetVaultModel({
    required this.goldGrams,
    required this.usdOnHand,
    required this.eurOnHand,
    required this.keepGold,
  });
}

class AssetVaultModelAdapter extends TypeAdapter<AssetVaultModel> {
  @override
  final int typeId = 4;

  @override
  AssetVaultModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AssetVaultModel(
      goldGrams: fields[0] as double,
      usdOnHand: fields[1] as double,
      eurOnHand: fields[2] as double,
      keepGold: fields[3] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, AssetVaultModel obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.goldGrams)
      ..writeByte(1)
      ..write(obj.usdOnHand)
      ..writeByte(2)
      ..write(obj.eurOnHand)
      ..writeByte(3)
      ..write(obj.keepGold);
  }
}
