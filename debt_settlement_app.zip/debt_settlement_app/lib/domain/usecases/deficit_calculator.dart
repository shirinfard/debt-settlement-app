import '../../core/constants/app_constants.dart';
import '../../data/models/debt_model.dart';
import '../../data/models/expense_model.dart';
import '../../data/models/inflow_model.dart';
import '../../data/models/vault_model.dart';
import '../entities/financial_summary.dart';

/// Pure business logic — no Flutter, no Hive. Takes plain lists + rates,
/// returns a [FinancialSummary]. This is what makes priority sequencing
/// and deficit math independently unit-testable.
class DeficitCalculator {
  FinancialSummary calculate({
    required List<InflowModel> inflows,
    required List<DebtModel> debts,
    required List<ExpenseModel> expenses,
    required DailyRatesModel? rates,
    required AssetVaultModel? vault,
  }) {
    final receivedInflows = inflows
        .where((i) => i.status == InflowStatus.received)
        .fold<double>(0, (sum, i) => sum + i.amountTomans);

    final pendingInflows = inflows
        .where((i) => i.status == InflowStatus.pending)
        .fold<double>(0, (sum, i) => sum + i.amountTomans);

    final totalDebt =
        debts.fold<double>(0, (sum, d) => sum + d.amountTomans);
    final totalDebtRemaining =
        debts.fold<double>(0, (sum, d) => sum + d.remainingTomans);

    final totalExpenses =
        expenses.fold<double>(0, (sum, e) => sum + e.costTomans);
    final totalEssentialExpenses = expenses
        .where((e) => e.isEssential)
        .fold<double>(0, (sum, e) => sum + e.costTomans);

    final usdRate = rates?.usdToTomans ?? 0;
    final eurRate = rates?.eurToTomans ?? 0;
    final goldRate = rates?.goldPerGramTomans ?? 0;

    final goldGrams = vault?.goldGrams ?? 0;
    final usdOnHand = vault?.usdOnHand ?? 0;
    final eurOnHand = vault?.eurOnHand ?? 0;

    final goldValueTomans = goldGrams * goldRate;
    final usdValueTomans = usdOnHand * usdRate;
    final eurValueTomans = eurOnHand * eurRate;

    // Liquid cash on hand (cash-in-pocket only — gold decision handled below).
    final baseLiquid = receivedInflows + usdValueTomans + eurValueTomans;

    final liabilities = totalDebtRemaining + totalEssentialExpenses;

    // Scenario A: gold is SOLD -> counts as liquid cash.
    final netResultGoldSold = (baseLiquid + goldValueTomans) - liabilities;

    // Scenario B: gold is KEPT -> excluded from liquid cash entirely.
    final netResultGoldKept = baseLiquid - liabilities;

    return FinancialSummary(
      totalInflowsReceived: receivedInflows,
      totalInflowsPending: pendingInflows,
      totalLiquidInflows: baseLiquid,
      totalDebt: totalDebt,
      totalDebtRemaining: totalDebtRemaining,
      totalExpenses: totalExpenses,
      totalEssentialExpenses: totalEssentialExpenses,
      goldValueTomans: goldValueTomans,
      usdValueTomans: usdValueTomans,
      eurValueTomans: eurValueTomans,
      netResultGoldSold: netResultGoldSold,
      netResultGoldKept: netResultGoldKept,
    );
  }
}
