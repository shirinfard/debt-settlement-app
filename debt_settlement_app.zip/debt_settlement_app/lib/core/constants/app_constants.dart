/// Central place for enums and fixed lookup lists used across the app.
/// Keeping these in one file avoids "magic strings" scattered through
/// the data/domain/presentation layers.

/// Status of an inflow (cash coming IN to the user).
enum InflowStatus { received, pending }

extension InflowStatusX on InflowStatus {
  String get label => switch (this) {
        InflowStatus.received => 'وصول‌شده',
        InflowStatus.pending => 'در انتظار',
      };
}

/// Status of a debt repayment.
enum DebtStatus { unpaid, partial, paid }

extension DebtStatusX on DebtStatus {
  String get label => switch (this) {
        DebtStatus.unpaid => 'پرداخت‌نشده',
        DebtStatus.partial => 'پرداخت‌جزئی',
        DebtStatus.paid => 'تسویه‌شده',
      };
}

/// Priority level for a debt/creditor. 1 = most urgent (legal action /
/// collateral at risk), 5 = least urgent.
enum DebtPriority { p1, p2, p3, p4, p5 }

extension DebtPriorityX on DebtPriority {
  int get level => index + 1;

  String get label => switch (this) {
        DebtPriority.p1 => 'فوری / حقوقی / وثیقه',
        DebtPriority.p2 => 'بسیار مهم',
        DebtPriority.p3 => 'مهم',
        DebtPriority.p4 => 'متوسط',
        DebtPriority.p5 => 'کم‌اهمیت',
      };

  static DebtPriority fromLevel(int level) => DebtPriority.values[
      (level.clamp(1, 5)) - 1];
}

/// Expense categories.
enum ExpenseCategory { business, living, repair, marketing }

extension ExpenseCategoryX on ExpenseCategory {
  String get label => switch (this) {
        ExpenseCategory.business => 'کسب‌وکار / تجهیزات',
        ExpenseCategory.living => 'هزینه‌های زندگی',
        ExpenseCategory.repair => 'تعمیرات',
        ExpenseCategory.marketing => 'بازاریابی',
      };
}

/// Supported currencies in the asset vault (Gold is tracked separately in grams).
enum AssetCurrency { usd, eur }

extension AssetCurrencyX on AssetCurrency {
  String get label => switch (this) {
        AssetCurrency.usd => 'دلار آمریکا',
        AssetCurrency.eur => 'یورو',
      };
}

/// Hive box names — single source of truth so a typo doesn't create a
/// silently-empty second box.
class HiveBoxes {
  static const inflows = 'box_inflows';
  static const debts = 'box_debts';
  static const expenses = 'box_expenses';
  static const rates = 'box_rates'; // daily exchange rates + gold price
  static const vault = 'box_vault'; // gold grams / usd / eur on hand
}
