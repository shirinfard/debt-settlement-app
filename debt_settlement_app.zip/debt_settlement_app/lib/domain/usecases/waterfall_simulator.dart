import '../../data/models/debt_model.dart';
import '../entities/financial_summary.dart';

/// Simulates paying off debts strictly in priority order (1 -> 5, and by
/// largest remaining amount within the same priority tier) from a single
/// pool of available cash. This answers: "if I have X Tomans today, which
/// creditors get paid, and who is left unpaid?"
class WaterfallSimulator {
  WaterfallResult run({
    required double availableCash,
    required List<DebtModel> debts,
  }) {
    // Sort: lowest priority number first (most urgent), then largest
    // remaining balance first within the same tier (clears the biggest
    // legal/collateral exposure first).
    final ordered = [...debts]
      ..sort((a, b) {
        final byPriority = a.priority.level.compareTo(b.priority.level);
        if (byPriority != 0) return byPriority;
        return b.remainingTomans.compareTo(a.remainingTomans);
      });

    double cash = availableCash;
    final steps = <WaterfallStep>[];

    for (final debt in ordered) {
      final due = debt.remainingTomans;
      if (due <= 0) continue;

      final paid = due <= cash ? due : (cash > 0 ? cash : 0);
      cash -= paid;

      steps.add(WaterfallStep(
        creditorName: debt.creditorName,
        priorityLevel: debt.priority.level,
        amountDue: due,
        amountPaid: paid,
        remainingAfter: due - paid,
        cashLeftAfterThisStep: cash,
        fullyPaid: paid >= due,
      ));
    }

    final totalUnpaid =
        steps.fold<double>(0, (sum, s) => sum + s.remainingAfter);

    return WaterfallResult(
      steps: steps,
      startingCash: availableCash,
      cashRemainingAtEnd: cash,
      totalUnpaid: totalUnpaid,
    );
  }
}
