import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';

/// Small color-coded pill showing a debt's priority level.
/// 1 = urgent (red), fading toward calmer tones at 5.
class PriorityTag extends StatelessWidget {
  final DebtPriority priority;

  const PriorityTag({super.key, required this.priority});

  Color get _color => switch (priority) {
        DebtPriority.p1 => AppColors.urgentRed,
        DebtPriority.p2 => const Color(0xFFE07856),
        DebtPriority.p3 => AppColors.pendingAmber,
        DebtPriority.p4 => const Color(0xFF8FA6C9),
        DebtPriority.p5 => AppColors.textSecondary,
      };

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _color.withOpacity(0.5)),
      ),
      child: Text(
        'اولویت ${priority.level} · ${priority.label}',
        style: TextStyle(color: _color, fontSize: 11, fontWeight: FontWeight.w600),
      ),
    );
  }
}

/// Status pill for debts (paid / partial / unpaid) or inflows (received/pending).
class StatusTag extends StatelessWidget {
  final String label;
  final Color color;

  const StatusTag({super.key, required this.label, required this.color});

  factory StatusTag.debt(DebtStatus status) {
    final (label, color) = switch (status) {
      DebtStatus.paid => (status.label, AppColors.inflowGreen),
      DebtStatus.partial => (status.label, AppColors.pendingAmber),
      DebtStatus.unpaid => (status.label, AppColors.urgentRed),
    };
    return StatusTag(label: label, color: color);
  }

  factory StatusTag.inflow(InflowStatus status) {
    final (label, color) = switch (status) {
      InflowStatus.received => (status.label, AppColors.inflowGreen),
      InflowStatus.pending => (status.label, AppColors.pendingAmber),
    };
    return StatusTag(label: label, color: color);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label, style: TextStyle(color: color, fontSize: 11)),
    );
  }
}
