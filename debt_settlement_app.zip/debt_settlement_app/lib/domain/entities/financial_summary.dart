/// Pure data holder returned by the calculation engine — has no
/// dependency on Hive or Flutter, so it's trivially unit-testable.
class FinancialSummary {
  final double totalInflowsReceived;
  final double totalInflowsPending;
  final double totalLiquidInflows; // received + vault cash converted to Tomans

  final double totalDebt;
  final double totalDebtRemaining;

  final double totalExpenses;
  final double totalEssentialExpenses;

  final double goldValueTomans;
  final double usdValueTomans;
  final double eurValueTomans;

  /// Deficit/surplus WITH gold treated as liquid (i.e. gold sold).
  final double netResultGoldSold;

  /// Deficit/surplus WITH gold excluded from liquid cash (i.e. gold kept
  /// as a hedge / collateral-safe asset).
  final double netResultGoldKept;

  const FinancialSummary({
    required this.totalInflowsReceived,
    required this.totalInflowsPending,
    required this.totalLiquidInflows,
    required this.totalDebt,
    required this.totalDebtRemaining,
    required this.totalExpenses,
    required this.totalEssentialExpenses,
    required this.goldValueTomans,
    required this.usdValueTomans,
    required this.eurValueTomans,
    required this.netResultGoldSold,
    required this.netResultGoldKept,
  });

  bool get isDeficitIfGoldKept => netResultGoldKept < 0;
  bool get isDeficitIfGoldSold => netResultGoldSold < 0;
}

/// One line of the waterfall settlement simulation — shows exactly what
/// happened when a debt was fed through the available-cash queue.
class WaterfallStep {
  final String creditorName;
  final int priorityLevel;
  final double amountDue;
  final double amountPaid;
  final double remainingAfter;
  final double cashLeftAfterThisStep;
  final bool fullyPaid;

  const WaterfallStep({
    required this.creditorName,
    required this.priorityLevel,
    required this.amountDue,
    required this.amountPaid,
    required this.remainingAfter,
    required this.cashLeftAfterThisStep,
    required this.fullyPaid,
  });
}

class WaterfallResult {
  final List<WaterfallStep> steps;
  final double startingCash;
  final double cashRemainingAtEnd;
  final double totalUnpaid;

  const WaterfallResult({
    required this.steps,
    required this.startingCash,
    required this.cashRemainingAtEnd,
    required this.totalUnpaid,
  });
}
