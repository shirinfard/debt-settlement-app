import 'package:uuid/uuid.dart';
import '../../core/constants/app_constants.dart';
import '../local/hive_service.dart';
import '../models/inflow_model.dart';
import '../models/debt_model.dart';
import '../models/expense_model.dart';
import '../models/vault_model.dart';

/// Single point of access to persisted data. The presentation layer
/// (providers) never talks to Hive directly — only through this repository.
/// This is what keeps the architecture swappable (Hive -> SQLite/Room/etc.)
/// without touching UI or business-logic code.
class FinanceRepository {
  static const _uuid = Uuid();

  // ---------------- Inflows ----------------
  List<InflowModel> getInflows() => HiveService.inflowBox.values.toList();

  Future<void> saveInflow(InflowModel model) async {
    await HiveService.inflowBox.put(model.id, model);
  }

  Future<InflowModel> addInflow({
    required String title,
    required double amountTomans,
    required InflowStatus status,
    DateTime? targetDate,
    String notes = '',
  }) async {
    final model = InflowModel(
      id: _uuid.v4(),
      title: title,
      amountTomans: amountTomans,
      status: status,
      targetDate: targetDate,
      notes: notes,
    );
    await HiveService.inflowBox.put(model.id, model);
    return model;
  }

  Future<void> deleteInflow(String id) => HiveService.inflowBox.delete(id);

  // ---------------- Debts ----------------
  List<DebtModel> getDebts() => HiveService.debtBox.values.toList();

  Future<void> saveDebt(DebtModel model) async {
    await HiveService.debtBox.put(model.id, model);
  }

  Future<DebtModel> addDebt({
    required String creditorName,
    required double amountTomans,
    required DebtPriority priority,
    String collateralNote = '',
    DebtStatus status = DebtStatus.unpaid,
  }) async {
    final model = DebtModel(
      id: _uuid.v4(),
      creditorName: creditorName,
      amountTomans: amountTomans,
      priority: priority,
      collateralNote: collateralNote,
      status: status,
    );
    await HiveService.debtBox.put(model.id, model);
    return model;
  }

  Future<void> deleteDebt(String id) => HiveService.debtBox.delete(id);

  // ---------------- Expenses ----------------
  List<ExpenseModel> getExpenses() => HiveService.expenseBox.values.toList();

  Future<ExpenseModel> addExpense({
    required String itemName,
    required double costTomans,
    required ExpenseCategory category,
    required bool isEssential,
  }) async {
    final model = ExpenseModel(
      id: _uuid.v4(),
      itemName: itemName,
      costTomans: costTomans,
      category: category,
      isEssential: isEssential,
    );
    await HiveService.expenseBox.put(model.id, model);
    return model;
  }

  Future<void> saveExpense(ExpenseModel model) async {
    await HiveService.expenseBox.put(model.id, model);
  }

  Future<void> deleteExpense(String id) => HiveService.expenseBox.delete(id);

  // ---------------- Rates & Vault ----------------
  DailyRatesModel? getRates() {
    final box = HiveService.ratesBox;
    return box.isEmpty ? null : box.getAt(0);
  }

  Future<void> saveRates(DailyRatesModel rates) async {
    final box = HiveService.ratesBox;
    if (box.isEmpty) {
      await box.add(rates);
    } else {
      await box.putAt(0, rates);
    }
  }

  AssetVaultModel? getVault() {
    final box = HiveService.vaultBox;
    return box.isEmpty ? null : box.getAt(0);
  }

  Future<void> saveVault(AssetVaultModel vault) async {
    final box = HiveService.vaultBox;
    if (box.isEmpty) {
      await box.add(vault);
    } else {
      await box.putAt(0, vault);
    }
  }
}
