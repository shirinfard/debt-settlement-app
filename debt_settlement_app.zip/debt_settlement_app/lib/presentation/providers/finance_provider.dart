import 'package:flutter/foundation.dart';
import '../../core/constants/app_constants.dart';
import '../../data/models/debt_model.dart';
import '../../data/models/expense_model.dart';
import '../../data/models/inflow_model.dart';
import '../../data/models/vault_model.dart';
import '../../data/repositories/finance_repository.dart';
import '../../domain/entities/financial_summary.dart';
import '../../domain/usecases/deficit_calculator.dart';
import '../../domain/usecases/waterfall_simulator.dart';

/// Single source of truth for the UI. Every screen listens to this via
/// `context.watch<FinanceProvider>()`; every mutation goes through here so
/// the calculation engine is always re-run against fresh data.
class FinanceProvider extends ChangeNotifier {
  final FinanceRepository _repo;
  final DeficitCalculator _calculator = DeficitCalculator();
  final WaterfallSimulator _simulator = WaterfallSimulator();

  FinanceProvider(this._repo) {
    _loadAll();
  }

  List<InflowModel> _inflows = [];
  List<DebtModel> _debts = [];
  List<ExpenseModel> _expenses = [];
  DailyRatesModel? _rates;
  AssetVaultModel? _vault;

  bool isLoading = true;

  List<InflowModel> get inflows => List.unmodifiable(_inflows);
  List<DebtModel> get debts => List.unmodifiable(_debts);
  List<ExpenseModel> get expenses => List.unmodifiable(_expenses);
  DailyRatesModel? get rates => _rates;
  AssetVaultModel? get vault => _vault;

  /// Debts sorted for display: most urgent (priority 1) first.
  List<DebtModel> get debtsByPriority => [..._debts]
    ..sort((a, b) => a.priority.level.compareTo(b.priority.level));

  FinancialSummary get summary => _calculator.calculate(
        inflows: _inflows,
        debts: _debts,
        expenses: _expenses,
        rates: _rates,
        vault: _vault,
      );

  /// Cash available to allocate to debts in the waterfall: liquid cash
  /// (plus gold's value if [includeGold] / "sell gold" is selected), minus
  /// essential living/business expenses that must be covered first.
  WaterfallResult waterfall({required bool includeGold}) {
    final s = summary;
    final liquidWithGoldChoice =
        s.totalLiquidInflows + (includeGold ? s.goldValueTomans : 0);
    final cashForDebts = liquidWithGoldChoice - s.totalEssentialExpenses;
    return _simulator.run(
      availableCash: cashForDebts > 0 ? cashForDebts : 0,
      debts: _debts,
    );
  }

  Future<void> _loadAll() async {
    isLoading = true;
    notifyListeners();
    _inflows = _repo.getInflows();
    _debts = _repo.getDebts();
    _expenses = _repo.getExpenses();
    _rates = _repo.getRates();
    _vault = _repo.getVault();
    isLoading = false;
    notifyListeners();
  }

  // ---------------- Inflow mutations ----------------
  Future<void> addInflow({
    required String title,
    required double amountTomans,
    required InflowStatus status,
    DateTime? targetDate,
    String notes = '',
  }) async {
    final model = await _repo.addInflow(
      title: title,
      amountTomans: amountTomans,
      status: status,
      targetDate: targetDate,
      notes: notes,
    );
    _inflows = [..._inflows, model];
    notifyListeners();
  }

  Future<void> updateInflow(InflowModel updated) async {
    await _repo.saveInflow(updated);
    _inflows = [
      for (final i in _inflows) if (i.id == updated.id) updated else i
    ];
    notifyListeners();
  }

  Future<void> deleteInflow(String id) async {
    await _repo.deleteInflow(id);
    _inflows = _inflows.where((i) => i.id != id).toList();
    notifyListeners();
  }

  // ---------------- Debt mutations ----------------
  Future<void> addDebt({
    required String creditorName,
    required double amountTomans,
    required DebtPriority priority,
    String collateralNote = '',
  }) async {
    final model = await _repo.addDebt(
      creditorName: creditorName,
      amountTomans: amountTomans,
      priority: priority,
      collateralNote: collateralNote,
    );
    _debts = [..._debts, model];
    notifyListeners();
  }

  Future<void> updateDebt(DebtModel updated) async {
    await _repo.saveDebt(updated);
    _debts = [for (final d in _debts) if (d.id == updated.id) updated else d];
    notifyListeners();
  }

  /// Applies a partial or full payment to a debt and updates its status.
  Future<void> recordPayment(String debtId, double amount) async {
    final debt = _debts.firstWhere((d) => d.id == debtId);
    final newPaid = (debt.paidSoFarTomans + amount).clamp(0, debt.amountTomans);
    final newStatus = newPaid >= debt.amountTomans
        ? DebtStatus.paid
        : (newPaid > 0 ? DebtStatus.partial : DebtStatus.unpaid);
    final updated = debt.copyWith(paidSoFarTomans: newPaid, status: newStatus);
    await updateDebt(updated);
  }

  Future<void> deleteDebt(String id) async {
    await _repo.deleteDebt(id);
    _debts = _debts.where((d) => d.id != id).toList();
    notifyListeners();
  }

  // ---------------- Expense mutations ----------------
  Future<void> addExpense({
    required String itemName,
    required double costTomans,
    required ExpenseCategory category,
    required bool isEssential,
  }) async {
    final model = await _repo.addExpense(
      itemName: itemName,
      costTomans: costTomans,
      category: category,
      isEssential: isEssential,
    );
    _expenses = [..._expenses, model];
    notifyListeners();
  }

  Future<void> deleteExpense(String id) async {
    await _repo.deleteExpense(id);
    _expenses = _expenses.where((e) => e.id != id).toList();
    notifyListeners();
  }

  // ---------------- Rates & Vault ----------------
  Future<void> updateRates({
    required double usdToTomans,
    required double eurToTomans,
    required double goldPerGramTomans,
  }) async {
    final model = DailyRatesModel(
      usdToTomans: usdToTomans,
      eurToTomans: eurToTomans,
      goldPerGramTomans: goldPerGramTomans,
      updatedAt: DateTime.now(),
    );
    await _repo.saveRates(model);
    _rates = model;
    notifyListeners();
  }

  Future<void> updateVault({
    required double goldGrams,
    required double usdOnHand,
    required double eurOnHand,
    required bool keepGold,
  }) async {
    final model = AssetVaultModel(
      goldGrams: goldGrams,
      usdOnHand: usdOnHand,
      eurOnHand: eurOnHand,
      keepGold: keepGold,
    );
    await _repo.saveVault(model);
    _vault = model;
    notifyListeners();
  }

  Future<void> toggleKeepGold(bool value) async {
    final v = _vault;
    if (v == null) return;
    await updateVault(
      goldGrams: v.goldGrams,
      usdOnHand: v.usdOnHand,
      eurOnHand: v.eurOnHand,
      keepGold: value,
    );
  }
}
