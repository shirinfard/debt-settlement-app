import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/finance_provider.dart';
import '../widgets/summary_card.dart';

/// Lists necessary business/personal expenses & purchases.
class ExpensesScreen extends StatelessWidget {
  const ExpensesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();
    final expenses = provider.expenses;

    return Scaffold(
      appBar: AppBar(title: const Text('هزینه‌ها و خریدهای ضروری')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.pendingAmber,
        onPressed: () => _showAddSheet(context),
        child: const Icon(Icons.add, color: Colors.black),
      ),
      body: expenses.isEmpty
          ? const Center(
              child: Text('هنوز هزینه‌ای ثبت نشده است.',
                  style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: expenses.length,
              itemBuilder: (context, i) {
                final item = expenses[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.delete_outline,
                            color: AppColors.urgentRed, size: 20),
                        onPressed: () => provider.deleteExpense(item.id),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(item.itemName,
                                style: const TextStyle(
                                    color: AppColors.textPrimary,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                if (item.isEssential)
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 3),
                                    margin: const EdgeInsets.only(left: 8),
                                    decoration: BoxDecoration(
                                      color: AppColors.urgentRed
                                          .withOpacity(0.15),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: const Text('ضروری',
                                        style: TextStyle(
                                            color: AppColors.urgentRed,
                                            fontSize: 11)),
                                  ),
                                Text(item.category.label,
                                    style: const TextStyle(
                                        color: AppColors.textSecondary,
                                        fontSize: 11)),
                                const SizedBox(width: 8),
                                Text(formatTomans(item.costTomans),
                                    style: const TextStyle(
                                        color: AppColors.pendingAmber,
                                        fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  void _showAddSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const _AddExpenseSheet(),
    );
  }
}

class _AddExpenseSheet extends StatefulWidget {
  const _AddExpenseSheet();
  @override
  State<_AddExpenseSheet> createState() => _AddExpenseSheetState();
}

class _AddExpenseSheetState extends State<_AddExpenseSheet> {
  final _nameCtrl = TextEditingController();
  final _costCtrl = TextEditingController();
  ExpenseCategory _category = ExpenseCategory.living;
  bool _essential = true;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: 20 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('افزودن هزینه جدید',
              style: TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
          const SizedBox(height: 16),
          TextField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'نام قلم هزینه')),
          const SizedBox(height: 12),
          TextField(
            controller: _costCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'هزینه (تومان)'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<ExpenseCategory>(
            value: _category,
            dropdownColor: AppColors.surfaceElevated,
            decoration: const InputDecoration(labelText: 'دسته‌بندی'),
            items: ExpenseCategory.values
                .map((c) => DropdownMenuItem(value: c, child: Text(c.label)))
                .toList(),
            onChanged: (v) => setState(() => _category = v ?? _category),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Checkbox(
                value: _essential,
                activeColor: AppColors.urgentRed,
                onChanged: (v) => setState(() => _essential = v ?? true),
              ),
              const Text('این هزینه ضروری است',
                  style: TextStyle(color: AppColors.textPrimary)),
            ],
          ),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: _submit, child: const Text('ذخیره')),
        ],
      ),
    );
  }

  void _submit() {
    final name = _nameCtrl.text.trim();
    final cost = double.tryParse(_costCtrl.text) ?? 0;
    if (name.isEmpty || cost <= 0) return;
    context.read<FinanceProvider>().addExpense(
          itemName: name,
          costTomans: cost,
          category: _category,
          isEssential: _essential,
        );
    Navigator.pop(context);
  }
}
