import 'package:hive_flutter/hive_flutter.dart';
import '../../core/constants/app_constants.dart';
import '../models/inflow_model.dart';
import '../models/debt_model.dart';
import '../models/expense_model.dart';
import '../models/vault_model.dart';

/// Registers adapters and opens all boxes once at app startup.
/// Call `HiveService.init()` before `runApp(...)`.
class HiveService {
  static Future<void> init() async {
    await Hive.initFlutter();

    Hive.registerAdapter(InflowModelAdapter());
    Hive.registerAdapter(DebtModelAdapter());
    Hive.registerAdapter(ExpenseModelAdapter());
    Hive.registerAdapter(DailyRatesModelAdapter());
    Hive.registerAdapter(AssetVaultModelAdapter());

    await Future.wait([
      Hive.openBox<InflowModel>(HiveBoxes.inflows),
      Hive.openBox<DebtModel>(HiveBoxes.debts),
      Hive.openBox<ExpenseModel>(HiveBoxes.expenses),
      Hive.openBox<DailyRatesModel>(HiveBoxes.rates),
      Hive.openBox<AssetVaultModel>(HiveBoxes.vault),
    ]);
  }

  static Box<InflowModel> get inflowBox => Hive.box(HiveBoxes.inflows);
  static Box<DebtModel> get debtBox => Hive.box(HiveBoxes.debts);
  static Box<ExpenseModel> get expenseBox => Hive.box(HiveBoxes.expenses);
  static Box<DailyRatesModel> get ratesBox => Hive.box(HiveBoxes.rates);
  static Box<AssetVaultModel> get vaultBox => Hive.box(HiveBoxes.vault);
}
